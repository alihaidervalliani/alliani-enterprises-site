import { useState } from "react";
import Link from "next/link";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log("Form submitted:", form);
    setSubmitted(true);
  };

  return (
    <>
      <header className="bg-blue-900 text-white py-4 shadow">
        <nav className="max-w-6xl mx-auto flex justify-between px-6">
          <Link href="/" className="text-xl font-bold">Valliani Enterprises</Link>
          <div className="space-x-6">
            <Link href="/about" className="hover:underline">About</Link>
            <Link href="/services" className="hover:underline">Products</Link>
            <Link href="/contact" className="underline font-medium">Contact</Link>
          </div>
        </nav>
      </header>

      <main className="min-h-screen bg-white text-gray-900 px-6 py-16">
        <section className="max-w-4xl mx-auto mb-16 text-center">
          <img src="/images/spices-banner.jpg" alt="Spices banner" className="w-full h-64 object-cover rounded-xl mb-6" />
          <h1 className="text-4xl font-bold mb-4">Welcome to Valliani Enterprises</h1>
          <p className="text-lg text-gray-700">
            We specialize in high-quality <strong>spices</strong> and <strong>packaging solutions</strong> tailored for
            retail markets, hotels, and restaurants. Discover our commitment to quality, consistency, and
            customer satisfaction.
          </p>
        </section>

        <section className="max-w-5xl mx-auto mb-20">
          <h2 className="text-3xl font-semibold mb-6 text-center">Our Product Offerings</h2>
          <div className="grid md:grid-cols-2 gap-10">
            <div className="border rounded-2xl p-6 shadow-md">
              <img src="/images/spices.jpg" alt="Spices" className="w-full h-48 object-cover rounded-lg mb-4" />
              <h3 className="text-xl font-bold mb-2">🌶️ Spices</h3>
              <p className="text-gray-700">
                We offer a rich selection of pure, hand-picked spices including cumin, turmeric, red chili,
                coriander, and mixed blends. Available in bulk or consumer-ready packs.
              </p>
            </div>
            <div className="border rounded-2xl p-6 shadow-md">
              <img src="/images/packaging.jpg" alt="Packaging" className="w-full h-48 object-cover rounded-lg mb-4" />
              <h3 className="text-xl font-bold mb-2">📦 Packaging Solutions</h3>
              <p className="text-gray-700">
                Custom packaging options for retail shelves, restaurant kitchens, and hospitality chains.
                Flexible sizes, eco-friendly materials, and private labeling available.
              </p>
            </div>
          </div>
        </section>

        <section className="max-w-2xl mx-auto">
          <h2 className="text-2xl font-semibold mb-4 text-center">Contact Us</h2>

          <p className="text-center mb-6 text-gray-700">
            Reach out to <strong>Valliani Enterprises</strong> via the form below or email us at:
            <br />
            <a href="mailto:vallianienterprises@gmail.com" className="text-blue-600 underline">
              vallianienterprises@gmail.com
            </a>
          </p>

          <div className="mb-10 text-center text-gray-600">
            <p>📍 1st Floor B5/1 Kehkashan Town Houses</p>
            <p>Plot # FL-2, Block 5 Clifton, Karachi, Pakistan</p>
          </div>

          {submitted ? (
            <p className="text-center text-green-600 font-medium">Thank you for contacting us!</p>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <input
                type="text"
                name="name"
                placeholder="Your Name"
                className="w-full border p-2 rounded"
                value={form.name}
                onChange={handleChange}
                required
              />
              <input
                type="email"
                name="email"
                placeholder="Your Email"
                className="w-full border p-2 rounded"
                value={form.email}
                onChange={handleChange}
                required
              />
              <textarea
                name="message"
                placeholder="Your Message"
                className="w-full border p-2 rounded"
                rows="5"
                value={form.message}
                onChange={handleChange}
                required
              ></textarea>
              <button type="submit" className="bg-blue-900 text-white px-6 py-2 rounded hover:bg-blue-800">
                Send Message
              </button>
            </form>
          )}
        </section>
      </main>

      <footer className="bg-gray-100 text-center text-sm text-gray-600 py-6 mt-16">
        © 2025 Valliani Enterprises. All rights reserved.
      </footer>
    </>
  );
}
